import 'package:flutter/material.dart';

import '../widgets/bottom_navbar.dart';
import '../widgets/dashboard_appbar.dart';
import '../widgets/quick_action_card.dart';
import '../widgets/recent_order_tile.dart';
import '../widgets/summary_card.dart';
import 'package:go_router/go_router.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF7F8FC),

      appBar: const DashboardAppBar(),

      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Good Morning 👋",
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),

              const SizedBox(height: 6),

              const Text(
                "Here's your business summary.",
                style: TextStyle(color: Colors.grey),
              ),

              const SizedBox(height: 25),

              Row(
                children: [
                  Expanded(
                    child: SummaryCard(
                      title: "Today's Sales",
                      value: "₹ 4,250",
                      color: Color(0xff16A34A),
                      icon: Icons.currency_rupee,
                    ),
                  ),

                  SizedBox(width: 15),

                  Expanded(
                    child: SummaryCard(
                      title: "Orders",
                      value: "38",
                      color: Color(0xff2563EB),
                      icon: Icons.shopping_bag,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 15),

              Row(
                children: const [
                  Expanded(
                    child: SummaryCard(
                      title: "Menu Items",
                      value: "24",
                      color: Color(0xffF59E0B),
                      icon: Icons.restaurant_menu,
                    ),
                  ),

                  SizedBox(width: 15),

                  Expanded(
                    child: SummaryCard(
                      title: "Pending",
                      value: "5",
                      color: Color(0xffDC2626),
                      icon: Icons.timer,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 35),

              const Text(
                "Quick Actions",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22),
              ),

              const SizedBox(height: 20),

              GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 15,
                mainAxisSpacing: 15,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                childAspectRatio: 1.3,
                children: [
                  QuickActionCard(
                    title: "Categories",
                    icon: Icons.category,
                    color: const Color(0xff16A34A),
                    onTap: () {
                      context.push("/categories");
                    },
                  ),
                  QuickActionCard(
                    title: "Menu",
                    icon: Icons.restaurant_menu,
                    color: const Color(0xffF59E0B),
                    onTap: () {
                      context.push("/menu");
                    },
                  ),

                  QuickActionCard(
                    title: "Orders",
                    icon: Icons.shopping_cart,
                    color: const Color(0xff2563EB),
                    onTap: () {
                      context.push("/orders");
                    },
                  ),

                  QuickActionCard(
                    title: "New Order",
                    icon: Icons.point_of_sale,
                    color: const Color(0xff8B5CF6),
                    onTap: () {
                      context.push("/orders/create");
                    },
                  ),

                  QuickActionCard(
                    title: "Profile",
                    icon: Icons.person,
                    color: const Color(0xffF97316),
                    onTap: () {
                      // Profile page
                    },
                  ),
                ],
              ),

              const SizedBox(height: 35),

              const Text(
                "Recent Orders",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22),
              ),

              const SizedBox(height: 20),

              const RecentOrderTile(
                orderNo: "#1001",
                customer: "Walk-in Customer",
                amount: "₹180",
              ),

              const RecentOrderTile(
                orderNo: "#1002",
                customer: "Rahul",
                amount: "₹350",
              ),

              const RecentOrderTile(
                orderNo: "#1003",
                customer: "Amit",
                amount: "₹520",
              ),
            ],
          ),
        ),
      ),
    );
  }
}
