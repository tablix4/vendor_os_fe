class MenuItemModel {
  final String id;
  final String categoryId;
  final String categoryName;

  final String name;
  final String? description;

  final double price;

  final String? image;

  final bool isAvailable;

  MenuItemModel({
    required this.id,
    required this.categoryId,
    required this.categoryName,
    required this.name,
    this.description,
    required this.price,
    this.image,
    required this.isAvailable,
  });

  factory MenuItemModel.fromJson(Map<String, dynamic> json) {
    return MenuItemModel(
      id: json["id"],
      categoryId: json["categoryId"],
      categoryName: json["category"]["name"],
      name: json["name"],
      description: json["description"],
      price: double.parse(json["price"].toString()),
      image: json["image"],
      isAvailable: json["isAvailable"],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "categoryId": categoryId,
      "name": name,
      "description": description,
      "price": price,
      "image": image,
      "isAvailable": isAvailable,
    };
  }
}
