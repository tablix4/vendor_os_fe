import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../shared/widgets/app_page.dart';
import '../../../menu/presentation/providers/menu_provider.dart';
import '../../data/models/create_order_item.dart';
import '../../data/models/create_order_request.dart';
import '../providers/order_provider.dart';
import '../widgets/customer_info_section.dart';
import '../widgets/menu_item_selector_card.dart';
import '../widgets/order_summary_card.dart';
import '../widgets/selected_order_item_card.dart';

class CreateOrderPage extends ConsumerStatefulWidget {
  const CreateOrderPage({super.key});

  @override
  ConsumerState<CreateOrderPage> createState() => _CreateOrderPageState();
}

class _CreateOrderPageState extends ConsumerState<CreateOrderPage> {
  final TextEditingController _customerNameController = TextEditingController();
  final TextEditingController _customerPhoneController =
      TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(orderProvider.notifier).clearCart();
    });
  }

  @override
  void dispose() {
    _customerNameController.dispose();
    _customerPhoneController.dispose();
    super.dispose();
  }

  Future<void> _placeOrder() async {
    final orderState = ref.read(orderProvider);
    if (orderState.cart.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please select at least one item.")),
      );
      return;
    }

    final request = CreateOrderRequest(
      customerName: _customerNameController.text.trim().isEmpty
          ? null
          : _customerNameController.text.trim(),
      customerPhone: _customerPhoneController.text.trim().isEmpty
          ? null
          : _customerPhoneController.text.trim(),
      items: orderState.cart
          .map(
            (selected) => CreateOrderItem(
              menuItemId: selected.menuItem.id,
              quantity: selected.quantity,
            ),
          )
          .toList(),
    );

    try {
      await ref.read(orderProvider.notifier).createOrder(request);
      if (!mounted) {
        return;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Order created successfully.")),
      );
      Navigator.pop(context);
    } catch (e) {
      if (!mounted) {
        return;
      }
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  @override
  Widget build(BuildContext context) {
    final menuState = ref.watch(menuProvider);
    final orderState = ref.watch(orderProvider);

    return Scaffold(
      bottomNavigationBar: menuState.maybeWhen(
        data: (_) => OrderSummaryCard(
          loading: orderState.isCreatingOrder,
          onPlaceOrder: _placeOrder,
        ),
        orElse: () => const SizedBox.shrink(),
      ),
      body: AppPage(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20),
            Row(
              children: [
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.arrow_back_ios),
                ),
                const SizedBox(width: 12),
                const Text(
                  "Create Order",
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            const SizedBox(height: 24),
            CustomerInfoSection(
              customerNameController: _customerNameController,
              customerPhoneController: _customerPhoneController,
            ),
            const SizedBox(height: 30),
            const Text(
              "Menu",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: menuState.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (error, _) => Center(child: Text(error.toString())),
                data: (menuItems) {
                  return ListView(
                    padding: const EdgeInsets.only(bottom: 120),
                    children: [
                      ...menuItems.map(
                        (item) => MenuItemSelectorCard(item: item),
                      ),
                      const SizedBox(height: 30),
                      const Text(
                        "Selected Items",
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 16),
                      if (orderState.cart.isEmpty)
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 40),
                          child: Center(child: Text("No items selected.")),
                        )
                      else
                        ...orderState.cart.map(
                          (item) => SelectedOrderItemCard(item: item),
                        ),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
